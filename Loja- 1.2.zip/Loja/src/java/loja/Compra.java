package loja;

import dados.Banco;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author Vagner
 */
public class Compra {

    
    private int cidClientes;
    private int cidProdutos;
    private Cliente cliente;
    private Produto produto;
    
    public Compra(int cidClientes,int cidProdutos) {
        this.cidClientes = cidClientes;
        this.cidProdutos = cidProdutos;
    }
     public int getCidClientes() {
        return cidClientes;
    }

    public void setCidClientes(int cidClientes) {
        this.cidClientes = cidClientes;
    }

    public int getCidProdutos() {
        return cidProdutos;
    }

    public void setCidProdutos(int cidProdutos) {
        this.cidProdutos = cidProdutos;
    }
    
    public void realizarCompra(){
        
        
        
        Connection conexao = new Banco().getConnection();

			String sql = "insert into itens (idclientes, idprodutos,qtdselecionada) values (?, ?, 1)";
                        String sql2 = "UPDATE produtos set produtosqtd = produtosqtd -1 WHERE idprodutos = ? ";
			
			PreparedStatement query;
                        PreparedStatement query2;
			try {
				query = conexao.prepareStatement(sql);
                                query.setInt(1, getCidClientes());
                                query.setInt(2, getCidProdutos());

                                query.execute();
                                query.close();
                                
                                
                                query2 = conexao.prepareStatement(sql2);
                                query2.setInt(1, getCidProdutos());
                                

                                query2.execute();
                                query2.close();
                                
                                conexao.close();
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
			
                       
       
    }
    
    
    public ArrayList<Itens> obterhistorico(int id){
        
        Connection conecta = new Banco().getConnection();
		
				
		String sql = "Select * From itens,clientes,produtos "
                        + "where itens.idclientes = clientes.idclientes "
                        + "and itens.idprodutos = produtos.idprodutos "
                        + "and clientes.idclientes = ?";
		
		
		PreparedStatement query;
                ArrayList<Itens> ls = new ArrayList<Itens>();
		try {
			query = conecta.prepareStatement(sql);
			query.setInt(1, id);
                        ResultSet rs = query.executeQuery();
                        int registro = 0;
                        while (rs.next()) {
                            
                        int idclientes = rs.getInt("idclientes");    
                        String clientesnome = rs.getString("clientesnome");
                        String clientesemail = rs.getString("clientesemail");
                        String clientescpf = rs.getString("clientescpf");
                        String clientesend = rs.getString("clientesend");
                        
                        Cliente c = new Cliente(clientesnome,clientesemail,clientescpf,clientesend,idclientes);
                        
                        
                        
                        int idprodutos = rs.getInt("idprodutos");
                        int produtosqtd = rs.getInt("produtosqtd");
                        String produtosdsc = rs.getString("produtosdsc");
                        String produtosnome = rs.getString("produtosnome");
                        Double produtosvalor = rs.getDouble("produtosvalor");
                        
                        Produto p = new Produto(produtosnome, produtosdsc,produtosqtd, idprodutos,produtosvalor);
                        
                         int qtdselecionada = rs.getInt("qtdselecionada");  
                        Itens itens = new Itens(c,p,qtdselecionada);
                        
                        ls.add(itens);
                        }
                        rs.close();
                        query.close();
                        conecta.close();

                      
            
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }

                               


         return ls;
        
    }
    
    
}
