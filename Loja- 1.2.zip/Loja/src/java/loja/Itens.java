
package loja;

/**
 *
 * @author Vagner
 */
import loja.Cliente;
import loja.Produto;

public class Itens {
    
    private Cliente cliente;
    private Produto produto;
    private int qtdselecionada;
    
    public Itens (Cliente cliente, Produto produto, int qtdselecionada) {
        this.cliente = cliente;
        this.produto = produto;
        this.qtdselecionada = qtdselecionada;
        
    }
    
    public String nomecliente(){
        return cliente.getName();
    }
    public String nomeproduto(){
        return produto.getProdutosnome();
    }
    public int qtdproduto(){
        return produto.getProdutosqtd();
    }
    public int obterqtd(){
        return qtdselecionada;
    }
    
    public double obetervalorproduto(){
        return produto.getvalorproduto();
        
    }
    
}
